package ch.nebulaWatches.nebulaWatchesAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NebulaWatchesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
