package ch.nebulaWatches.nebulaWatchesAPI.security.models;

public enum Role {

    USER,
    ADMIN
}
